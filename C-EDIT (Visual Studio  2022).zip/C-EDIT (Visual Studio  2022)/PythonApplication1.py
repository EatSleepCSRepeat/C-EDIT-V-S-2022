import tkinter as tk
from tkinter import Button, Text, filedialog, messagebox, OptionMenu

def geometry(width: int, height: int):
    return f"{width}x{height}"

def save():
    selected_language = lang_var.get()
    
    # Define file types based on selected language
    if selected_language == "C#":
        filetypes = [("C# files", "*.cs"), ("All files", "*.*")]
        default_extension = ".cs"
    elif selected_language == "C++":
        filetypes = [("C++ files", "*.cpp"), ("All files", "*.*")]
        default_extension = ".cpp"
    elif selected_language == "Objective C":
        filetypes = [("Objective C files", "*.m"), ("All files", "*.*")]
        default_extension = ".m"
    elif selected_language == "C":
        filetypes = [("C files", "*.c"), ("All files", "*.*")]
        default_extension = ".c"
    else:
        filetypes = [("All files", "*.*")]
        default_extension = ""
    
    file = filedialog.asksaveasfilename(
        defaultextension=default_extension,
        filetypes=filetypes
    )
    if file:
        with open(file, 'w') as f:
            f.write(text.get("1.0", tk.END))
        messagebox.showinfo(f"File Saved", f"Written code to {file}")

# Create the main application window
app = tk.Tk()
app.geometry(geometry(400, 300))
app.title("C-EDIT")

# Language options for C programming languages
c_languages = ["C", "C++", "Objective C", "C#"]

# StringVar to store the selected language
lang_var = tk.StringVar(app)
lang_var.set(c_languages[0])  # Set default language

# Dropdown menu for selecting the C language
language_menu = OptionMenu(app, lang_var, *c_languages)
language_menu.pack(pady=10)

# Text widget for code editing
text = Text(app, width=30, height=10)
text.pack(fill="both", expand=True, padx=10, pady=10)

# Save button
button_saveas = Button(app, text="Save As...", command=save)
button_saveas.pack(pady=10)

# Set application icon
icon_path = 'csharp.ico'
app.iconbitmap(default=icon_path)

# Run the main event loop
app.mainloop()
